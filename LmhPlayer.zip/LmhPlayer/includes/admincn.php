<?php
add_action('admin_menu', 'lmhplayer_menu_page');
register_activation_hook(__FILE__, 'LmhPlayer_install');
register_deactivation_hook(__FILE__, 'LmhPlayer_uninstall');

function LmhPlayer_install(){
	add_option('name','xxx');
	add_option('lmhplayer_domain','xxx');
	add_option('lmhplayer_name','xxx');
	add_option('lmhplayer_key','xxx');
}

function LmhPlayer_uninstall(){
	//update_option('name','xxx');
	deltee_option('name');
	deltee_option('lmhplayer_domain','http://');
	deltee_option('lmhplayer_name','雅趴小栈');
	deltee_option('lmhplayer_key','$%^&*()(()(');
}

function lmhplayer_menu_page(){
    add_menu_page('Html5播放器设置', 'Html5播放器设置', 'administrator', 'lmhplayer_options', 'lmhplayer_options', plugins_url('LmhPlayer/images/icon.png'), 99);
}

//设置页面
function lmhplayer_options(){?>  
    <div class="lmhplayer">  
        <h2>Html5 播放器设置 API[免费版]</h2>
		播放器作者:<a href="http://www.limh.me/">明月浩空</a></br>
		<?php update_lmhplayer_options() ?>
        <form method="post">  
            <p>更新时间: <?php echo LmhPlayer_TIME; ?><p>
			<p>绑定域名:<input type="text" name="lmhplayer_domain" value="<?php echo get_option('lmhplayer_domain'); ?>" class="button-prim3ary" /> </p>
			<p>网站名称:<input type="text" name="lmhplayer_name" value="<?php echo get_option('lmhplayer_name'); ?>" class="button-prim3ary" /> </p>
			<p>激活码:<input type="text" name="lmhplayer_key" value="<?php echo get_option('lmhplayer_key'); ?>"/>  

            </p>  
 
            <p>  
                <input type="submit" name="submit" value="保存设置"  />  
            </p>  
        </form>  
    </div>  
<?php }

function update_lmhplayer_options(){
				if($_POST['submit']){
					$updated = false;
					if($_POST['lmhplayer_name']){
						update_option('lmhplayer_name',$_POST['lmhplayer_name']);
						$updated = true;
					}

					if($_POST['lmhplayer_domain']){
						update_option('lmhplayer_domain',$_POST['lmhplayer_domain']);
						$updated = true;
					}

					if($_POST['lmhplayer_key']){
						update_option('lmhplayer_key',$_POST['lmhplayer_key']);
						$updated = true;
					}

					if($updated){
						echo '设置成功';
					}else{
						echo '保存失败';
					}
				}
			}
?>