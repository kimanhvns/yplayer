<?php
/**
 * @package Lmh Player
 * @author DIng
 * @version 1.0
 */
/*
Plugin Name: Lmh Player
Plugin URI: http://www.iyapa.com/
Version: 1.0
Author: Ding
Author URI: http://www.iyapa.com/lmh-player/
Text Domain: Lmh-Player
Description: 使用明月播放器兼容Wp版本.感谢Lmh 的播放器
*/

define('LmhPlayer_TIME', '20150703');
define('LmhPlayer_URL', plugins_url('', __FILE__));
define('LmhPlayer_PATH', dirname(__FILE__));
define('LmhPlayer_ADMIN_URL', admin_url());

require LmhPlayer_PATH . '/includes/admincn.php';
require LmhPlayer_PATH . '/includes/template.php';

// 我勒个去你要出现在哪~~~╮(╯_╰)╭
add_action( 'admin_notices', 'hello_dolly' );
add_action( 'wp_head', 'player_css' );
add_action( 'wp_footer', 'player_main', 10);
add_action( 'wp_footer', 'player_js', 11);
?>
